package com.rabrap.pro;

import android.app.*;
import android.content.*;
import android.graphics.*;
import android.graphics.pdf.PdfDocument;
import android.net.Uri;
import android.os.*;
import android.print.PrintAttributes;
import android.print.PrintManager;
import android.provider.Settings;
import android.text.InputType;
import android.view.*;
import android.widget.*;
import androidx.core.content.FileProvider;
import java.io.*;
import java.text.*;
import java.util.*;
import org.json.*;

/**
 * RAB RAP PRO 2.0 - responsive wizard based Android application.
 * No fixed screen width is assumed; all controls use dp/weight and vertical scrolling.
 */
public class MainActivity extends Activity {
    static final int PICK_LOGO=10, PICK_SIGN=11, PICK_STAMP=12, SAVE_PDF=50;
    LinearLayout root, content, itemBox, navBar;
    TextView stepTitle, stepInfo;
    Button backBtn, nextBtn;
    EditText company,address,phone,email,npwp,nib,website,bank,docNo,project,location,customer,customerAddress,pic,extra,discount,ppn,pph,notes;
    Spinner typeSpinner, pphSpinner, templateSpinner;
    ImageView logoView,signView,stampView;
    Uri logoUri,signUri,stampUri;
    SharedPreferences prefs;
    int page=0;
    final int PAGES=6;
    ArrayList<Item> items=new ArrayList<>();
    ArrayList<LinearLayout> itemCards=new ArrayList<>();
    ArrayList<ArrayList<View>> pageViews=new ArrayList<>();
    CadView cadView;
    EditText cadWidth,cadLength,cadWall,cadTitle;
    Spinner cadUnit;
    ArrayList<CadObj> cadObjects=new ArrayList<>();
    boolean pagesInitialized=false;
    File lastPdf;

    static class Item {
        EditText name,desc,brand,model,unit,qty,price,itemDisc,internalCost,margin;
    }

    int dp(float v){ return (int)(v*getResources().getDisplayMetrics().density+0.5f); }
    int screenWidth(){ return getResources().getDisplayMetrics().widthPixels; }
    TextView text(String s,float size,boolean bold){
        TextView t=new TextView(this); t.setText(s); t.setTextSize(size); t.setTextColor(Color.rgb(38,50,56));
        t.setTypeface(Typeface.DEFAULT,bold?Typeface.BOLD:Typeface.NORMAL); t.setPadding(dp(2),dp(3),dp(2),dp(3)); return t;
    }
    EditText field(String hint){
        EditText e=new EditText(this); e.setHint(hint); e.setTextSize(14); e.setPadding(dp(12),dp(7),dp(12),dp(7));
        e.setBackgroundColor(Color.WHITE); e.setMinHeight(dp(48)); return e;
    }
    Button button(String label){
        Button b=new Button(this); b.setText(label); b.setAllCaps(false); b.setMinHeight(dp(48)); return b;
    }
    LinearLayout row(){ LinearLayout l=new LinearLayout(this); l.setOrientation(LinearLayout.HORIZONTAL); l.setGravity(Gravity.CENTER_VERTICAL); l.setPadding(0,dp(2),0,dp(2)); return l; }

    @Override public void onCreate(Bundle state){
        super.onCreate(state); prefs=getSharedPreferences("rabrap",MODE_PRIVATE); buildShell(); buildAllPages(); restoreProfile(); showPage(0);
    }

    void buildShell(){
        LinearLayout outer=new LinearLayout(this); outer.setOrientation(LinearLayout.VERTICAL); outer.setBackgroundColor(Color.rgb(244,247,249));
        LinearLayout header=new LinearLayout(this); header.setOrientation(LinearLayout.VERTICAL); header.setPadding(dp(16),dp(12),dp(16),dp(10)); header.setBackgroundColor(Color.rgb(20,63,91));
        TextView title=text("RAB & RAP PRO",22,true); title.setTextColor(Color.WHITE); header.addView(title);
        TextView sub=text("RAB • RAP • QUOTATION • PDF",11,false); sub.setTextColor(Color.WHITE); header.addView(sub);
        stepTitle=text("",16,true); stepTitle.setTextColor(Color.WHITE); stepTitle.setPadding(0,dp(8),0,0); header.addView(stepTitle);
        stepInfo=text("",11,false); stepInfo.setTextColor(Color.rgb(220,235,242)); header.addView(stepInfo);
        outer.addView(header,new LinearLayout.LayoutParams(-1,LinearLayout.LayoutParams.WRAP_CONTENT));
        ScrollView scroll=new ScrollView(this); scroll.setFillViewport(true); content=new LinearLayout(this); content.setOrientation(LinearLayout.VERTICAL); content.setPadding(dp(12),dp(12),dp(12),dp(12)); scroll.addView(content); outer.addView(scroll,new LinearLayout.LayoutParams(-1,0,1));
        navBar=new LinearLayout(this); navBar.setOrientation(LinearLayout.HORIZONTAL); navBar.setPadding(dp(8),dp(6),dp(8),dp(6)); navBar.setBackgroundColor(Color.WHITE);
        backBtn=button("‹ Kembali"); nextBtn=button("Lanjut ›");
        navBar.addView(backBtn,new LinearLayout.LayoutParams(0,dp(52),1)); navBar.addView(nextBtn,new LinearLayout.LayoutParams(0,dp(52),1));
        outer.addView(navBar,new LinearLayout.LayoutParams(-1,dp(64))); setContentView(outer);
        backBtn.setOnClickListener(v->{if(page>0)showPage(page-1);else finish();});
        nextBtn.setOnClickListener(v->{ if(page<PAGES-1) showPage(page+1); else outputMenu(); });
    }

    void buildAllPages(){
        pageViews.clear();
        for(int i=0;i<PAGES;i++){
            content.removeAllViews();
            if(i==0) pageCompany(); else if(i==1) pageDocument(); else if(i==2) pageItems(); else if(i==3) pageTax(); else if(i==4) pageCad(); else pageNotesOutput();
            ArrayList<View> list=new ArrayList<>();
            for(int j=0;j<content.getChildCount();j++) list.add(content.getChildAt(j));
            pageViews.add(list);
        }
        content.removeAllViews();
        pagesInitialized=true;
    }
    void showPage(int p){
        page=Math.max(0,Math.min(PAGES-1,p)); content.removeAllViews();
        for(View v:pageViews.get(page)) content.addView(v);
        stepTitle.setText((page+1)+" / "+PAGES+"  •  "+new String[]{"Profil Perusahaan","Data Dokumen","Item & Pekerjaan","Pajak & Perhitungan","Denah / CAD","Catatan & Output"}[page]);
        stepInfo.setText("Data tetap tersimpan saat berpindah langkah");
        backBtn.setText(page==0?"‹ Keluar":"‹ Kembali"); nextBtn.setText(page==PAGES-1?"📄 Buat PDF":"Lanjut ›");
        content.post(()->((ScrollView)content.getParent()).fullScroll(View.FOCUS_UP));
    }
    void section(String s){ TextView t=text(s,17,true); t.setTextColor(Color.rgb(20,63,91)); t.setPadding(0,dp(10),0,dp(6)); content.addView(t); }
    void addField(String label,EditText e){ content.addView(text(label,12,true)); content.addView(e,new LinearLayout.LayoutParams(-1,dp(52))); }
    void addFieldTall(String label,EditText e,int minLines){ e.setMinLines(minLines); content.addView(text(label,12,true)); content.addView(e,new LinearLayout.LayoutParams(-1,dp(Math.max(70,minLines*35)))); }

    void pageCompany(){
        section("PROFIL PERUSAHAAN");
        company=field("Nama perusahaan / badan usaha"); address=field("Alamat lengkap"); phone=field("Telepon / WhatsApp"); email=field("Email"); website=field("Website"); npwp=field("NPWP (opsional)"); nib=field("NIB (opsional)"); bank=field("Bank / rekening pembayaran (opsional)");
        addField("Nama perusahaan",company); addFieldTall("Alamat",address,2); addField("Telepon / WhatsApp",phone); addField("Email",email); addField("Website",website); addField("NPWP",npwp); addField("NIB",nib); addField("Bank / Rekening",bank);
        LinearLayout media=row(); logoView=imageBox("Logo",logoUri); signView=imageBox("Tanda tangan",signUri); stampView=imageBox("Stempel",stampUri); media.addView(logoView,new LinearLayout.LayoutParams(0,dp(105),1)); media.addView(signView,new LinearLayout.LayoutParams(0,dp(105),1)); media.addView(stampView,new LinearLayout.LayoutParams(0,dp(105),1)); content.addView(media);
        LinearLayout buttons=row(); Button l=button("📁 Logo"), s=button("✍ Tanda Tangan"), st=button("🖋 Stempel"); buttons.addView(l,new LinearLayout.LayoutParams(0,dp(50),1)); buttons.addView(s,new LinearLayout.LayoutParams(0,dp(50),1)); buttons.addView(st,new LinearLayout.LayoutParams(0,dp(50),1)); content.addView(buttons); l.setOnClickListener(v->pick(PICK_LOGO)); s.setOnClickListener(v->pick(PICK_SIGN)); st.setOnClickListener(v->pick(PICK_STAMP));
        content.addView(text("Tip: tampilan otomatis menyesuaikan HP kecil, tablet, dan mode landscape.",11,false));
    }
    ImageView imageBox(String label,Uri uri){ ImageView i=new ImageView(this); i.setScaleType(ImageView.ScaleType.CENTER_INSIDE); i.setBackgroundColor(Color.WHITE); if(uri!=null)i.setImageURI(uri); return i; }

    void pageDocument(){
        section("DATA DOKUMEN");
        typeSpinner=new Spinner(this); typeSpinner.setAdapter(new ArrayAdapter<String>(this,android.R.layout.simple_spinner_dropdown_item,new String[]{"RAB","RAP","QUOTATION"})); content.addView(text("Jenis dokumen",12,true)); content.addView(typeSpinner,new LinearLayout.LayoutParams(-1,dp(52)));
        docNo=field("Nomor dokumen"); project=field("Nama project"); location=field("Lokasi project"); customer=field("Customer / perusahaan tujuan"); customerAddress=field("Alamat customer"); pic=field("Up / PIC customer");
        docNo.setText(prefs.getString("docNo",autoNo())); addField("Nomor dokumen",docNo); addField("Nama project",project); addField("Lokasi project",location); addField("Customer",customer); addFieldTall("Alamat customer",customerAddress,2); addField("Up / PIC customer",pic);
        section("TEMPLATE PDF"); templateSpinner=new Spinner(this); templateSpinner.setAdapter(new ArrayAdapter<String>(this,android.R.layout.simple_spinner_dropdown_item,new String[]{"Formal","Modern","Minimal"})); content.addView(templateSpinner,new LinearLayout.LayoutParams(-1,dp(52)));
    }
    String autoNo(){ return "001/RAB/"+new SimpleDateFormat("MM/yyyy",Locale.US).format(new Date()); }

    void pageItems(){
        section("ITEM BARANG / PEKERJAAN");
        Button add=button("＋ Tambah Item"); add.setOnClickListener(v->addItem()); content.addView(add); itemBox=new LinearLayout(this); itemBox.setOrientation(LinearLayout.VERTICAL); content.addView(itemBox);
        if(items.isEmpty()) addItem(); else for(Item i:items) addItemView(i);
        content.addView(text("RAP: kolom biaya internal dan margin dapat ditambahkan pada pengembangan berikutnya tanpa ditampilkan di QUOTATION.",11,false));
    }
    void addItem(){ Item i=new Item(); items.add(i); addItemView(i); }
    EditText numField(String hint){ EditText e=field(hint); e.setInputType(InputType.TYPE_CLASS_NUMBER|InputType.TYPE_NUMBER_FLAG_DECIMAL); return e; }
    void addItemView(Item it){
        LinearLayout card=new LinearLayout(this); card.setOrientation(LinearLayout.VERTICAL); card.setPadding(dp(10),dp(8),dp(10),dp(8)); card.setBackgroundColor(Color.WHITE); card.setElevation(dp(2));
        TextView h=text("Item "+(itemCards.size()+1),14,true); card.addView(h);
        it.name=field("Nama barang / pekerjaan *"); it.desc=field("Spesifikasi / deskripsi teknis"); it.desc.setMinLines(2); it.brand=field("Brand / merk"); it.model=field("Type / model"); it.unit=field("Satuan (unit, m², set, lot)"); it.qty=numField("Qty"); it.price=numField("Harga satuan"); it.itemDisc=numField("Diskon item (%)"); it.internalCost=numField("Biaya internal RAP (opsional)"); it.margin=numField("Margin RAP (%)"); it.unit.setText("unit"); it.qty.setText("1"); it.itemDisc.setText("0");
        card.addView(it.name); card.addView(it.desc); card.addView(it.brand); card.addView(it.model);
        LinearLayout r1=row(); r1.addView(it.unit,new LinearLayout.LayoutParams(0,dp(52),1)); r1.addView(it.qty,new LinearLayout.LayoutParams(0,dp(52),1)); card.addView(r1);
        LinearLayout r2=row(); r2.addView(it.price,new LinearLayout.LayoutParams(0,dp(52),1)); r2.addView(it.itemDisc,new LinearLayout.LayoutParams(0,dp(52),1)); card.addView(r2);
        LinearLayout r3=row(); r3.addView(it.internalCost,new LinearLayout.LayoutParams(0,dp(52),1)); r3.addView(it.margin,new LinearLayout.LayoutParams(0,dp(52),1)); card.addView(r3);
        Button rm=button("Hapus item"); rm.setOnClickListener(v->{items.remove(it); rebuildItems();}); card.addView(rm);
        itemCards.add(card); itemBox.addView(card,new LinearLayout.LayoutParams(-1,LinearLayout.LayoutParams.WRAP_CONTENT));
    }
    void rebuildItems(){
        if(itemBox==null)return; itemBox.removeAllViews(); itemCards.clear();
        for(Item i:items) addItemView(i);
    }

    void pageTax(){
        section("PAJAK & PERHITUNGAN OTOMATIS");
        extra=field("Biaya tambahan / instalasi / mobilisasi"); discount=numField("Diskon total (%)"); ppn=numField("PPN (%)"); pph=numField("PPh (%)"); discount.setText("0"); ppn.setText("11"); pph.setText("0");
        addField("Biaya tambahan",extra); addField("Diskon total (%)",discount); addField("PPN (%)",ppn);
        pphSpinner=new Spinner(this); pphSpinner.setAdapter(new ArrayAdapter<String>(this,android.R.layout.simple_spinner_dropdown_item,new String[]{"Tanpa PPh","PPh 21","PPh 22","PPh 23","PPh 4(2) Final","PPh 26","PPh Custom"})); content.addView(text("Jenis PPh",12,true)); content.addView(pphSpinner,new LinearLayout.LayoutParams(-1,dp(52))); addField("Tarif PPh (%)",pph);
        Button calc=button("🧮 HITUNG TOTAL"); calc.setOnClickListener(v->showTotals()); content.addView(calc);
        content.addView(text("PPN dan PPh dapat diubah sesuai ketentuan transaksi. Aplikasi tidak mengunci tarif pajak.",11,false));
    }

    // ===== DENAH / CAD 2D =====
    static class CadObj {
        String type,label; float x,y,w,h,rotation;
        CadObj(String type,String label,float x,float y,float w,float h){this.type=type;this.label=label;this.x=x;this.y=y;this.w=w;this.h=h;}
    }
    class CadView extends View {
        Paint p=new Paint(Paint.ANTI_ALIAS_FLAG); float scale=1f, ox=0, oy=0, lastX,lastY; int selected=-1; boolean dragging=false; long downTime;
        CadView(Context c){super(c); setBackgroundColor(Color.WHITE); p.setTypeface(Typeface.DEFAULT); setFocusable(true);}
        float sx(float x){return x*scale+ox;} float sy(float y){return y*scale+oy;}
        void resetView(){scale=1f;ox=20;oy=20;invalidate();}
        @Override protected void onDraw(Canvas c){super.onDraw(c); p.setStyle(Paint.Style.FILL);p.setColor(Color.rgb(247,249,250));c.drawRect(0,0,getWidth(),getHeight(),p); drawGrid(c); for(int i=0;i<cadObjects.size();i++) drawObj(c,cadObjects.get(i),i==selected); p.setColor(Color.DKGRAY);p.setTextSize(dp(11));c.drawText("DENAH 2D • Grid 100 mm • Geser objek dengan sentuhan • Gunakan Zoom + / − untuk melihat detail",dp(10),getHeight()-dp(10),p);}
        void drawGrid(Canvas c){p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(1);p.setColor(Color.rgb(225,230,233));float step=Math.max(8,50*scale);for(float x=ox%step;x<getWidth();x+=step)c.drawLine(x,0,x,getHeight(),p);for(float y=oy%step;y<getHeight();y+=step)c.drawLine(0,y,getWidth(),y,p);p.setStyle(Paint.Style.FILL);}
        void drawObj(Canvas c,CadObj o,boolean sel){float x=sx(o.x),y=sy(o.y),w=o.w*scale,h=o.h*scale;p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(sel?3:2);p.setColor(sel?Color.rgb(22,125,106):Color.rgb(20,63,91));if("ROOM".equals(o.type)){c.drawRect(x,y,x+w,y+h,p);}else if("DOOR".equals(o.type)){c.drawRect(x,y,x+w,y+h,p);c.drawArc(new RectF(x,y,x+w*2,y+h*2),180,90,false,p);}else if("WINDOW".equals(o.type)){c.drawRect(x,y,x+w,y+h,p);c.drawLine(x,y+h/2,x+w,y+h/2,p);}else if("HEPA".equals(o.type)){c.drawRect(x,y,x+w,y+h,p);for(int k=1;k<4;k++)c.drawLine(x+w*k/4,y,x+w*k/4,y+h,p);}else if("LIGHT".equals(o.type)){c.drawOval(new RectF(x,y,x+w,y+h),p);c.drawLine(x,y+h/2,x+w,y+h/2,p);}else if("RETURN".equals(o.type)){c.drawRect(x,y,x+w,y+h,p);for(int k=1;k<4;k++)c.drawLine(x+w*k/4,y,x+w*k/4,y+h,p);}else if("AHU".equals(o.type)){c.drawRect(x,y,x+w,y+h,p);c.drawCircle(x+w/2,y+h/2,Math.min(w,h)/4,p);}else if("TABLE".equals(o.type)){c.drawRoundRect(new RectF(x,y,x+w,y+h),8,8,p);}else{c.drawRect(x,y,x+w,y+h,p);}p.setStyle(Paint.Style.FILL);p.setColor(Color.DKGRAY);p.setTextSize(Math.max(dp(8),Math.min(dp(12),dp(10)*scale)));c.drawText(o.label,x+4,y+h/2+4,p);}
        @Override public boolean onTouchEvent(android.view.MotionEvent e){int act=e.getActionMasked();if(act==MotionEvent.ACTION_DOWN){lastX=e.getX();lastY=e.getY();downTime=System.currentTimeMillis();selected=hit(lastX,lastY);dragging=true;invalidate();return true;} if(act==MotionEvent.ACTION_MOVE&&e.getPointerCount()==1&&dragging&&selected>=0){CadObj o=cadObjects.get(selected);o.x+=(e.getX()-lastX)/scale;o.y+=(e.getY()-lastY)/scale;lastX=e.getX();lastY=e.getY();invalidate();return true;} if(act==MotionEvent.ACTION_UP){dragging=false;return true;} return true;}
        int hit(float x,float y){for(int i=cadObjects.size()-1;i>=0;i--){CadObj o=cadObjects.get(i);if(x>=sx(o.x)-12&&x<=sx(o.x+o.w)+12&&y>=sy(o.y)-12&&y<=sy(o.y+o.h)+12)return i;}return -1;}
    }
    void pageCad(){
        section("DENAH / CAD 2D");
        TextView info=text("Buat sketsa denah seperti CAD sederhana. Ukuran menggunakan mm. Denah dapat digenerate otomatis, diedit, dimasukkan ke PDF dan dicetak.",11,false); content.addView(info);
        LinearLayout r=row(); cadTitle=field("Judul denah / nama ruang"); cadWidth=numField("Lebar (mm)"); cadLength=numField("Panjang (mm)"); cadWall=numField("Tebal dinding (mm)"); cadWidth.setText("6000");cadLength.setText("8000");cadWall.setText("100"); r.addView(cadWidth,new LinearLayout.LayoutParams(0,dp(52),1));r.addView(cadLength,new LinearLayout.LayoutParams(0,dp(52),1)); content.addView(cadTitle,new LinearLayout.LayoutParams(-1,dp(52)));content.addView(r);
        LinearLayout tools=row(); Button gen=button("⚙ Generate");Button reset=button("↺ Reset");Button del=button("⌫ Hapus objek");Button add=button("＋ Objek");tools.addView(gen,new LinearLayout.LayoutParams(0,dp(50),1));tools.addView(reset,new LinearLayout.LayoutParams(0,dp(50),1));tools.addView(del,new LinearLayout.LayoutParams(0,dp(50),1));tools.addView(add,new LinearLayout.LayoutParams(0,dp(50),1));content.addView(tools);
        cadView=new CadView(this); content.addView(cadView,new LinearLayout.LayoutParams(-1,dp(430)));
        gen.setOnClickListener(v->generateCad()); reset.setOnClickListener(v->{cadObjects.clear();cadView.resetView();cadView.invalidate();}); del.setOnClickListener(v->{if(cadView.selected>=0){cadObjects.remove(cadView.selected);cadView.selected=-1;cadView.invalidate();}}); add.setOnClickListener(v->cadObjectMenu());
        LinearLayout zoom=row();Button zin=button("＋ Zoom");Button zout=button("− Zoom");Button fit=button("⛶ Fit");zoom.addView(zin,new LinearLayout.LayoutParams(0,dp(50),1));zoom.addView(zout,new LinearLayout.LayoutParams(0,dp(50),1));zoom.addView(fit,new LinearLayout.LayoutParams(0,dp(50),1));content.addView(zoom); zin.setOnClickListener(v->{cadView.scale=Math.min(4f,cadView.scale*1.25f);cadView.invalidate();}); zout.setOnClickListener(v->{cadView.scale=Math.max(.25f,cadView.scale/1.25f);cadView.invalidate();}); fit.setOnClickListener(v->cadView.resetView());
        LinearLayout out=row();Button pdf=button("📄 PDF Denah");Button save=button("💾 Simpan PDF");Button print=button("🖨 Cetak");out.addView(pdf,new LinearLayout.LayoutParams(0,dp(50),1));out.addView(save,new LinearLayout.LayoutParams(0,dp(50),1));out.addView(print,new LinearLayout.LayoutParams(0,dp(50),1));content.addView(out);
        pdf.setOnClickListener(v->createCadPdf());save.setOnClickListener(v->{try{File f=createCadPdfFile();saveToDevice(f);}catch(Exception e){Toast.makeText(this,"Gagal: "+e.getMessage(),Toast.LENGTH_LONG).show();}});print.setOnClickListener(v->createCadPdfAndPrint());
        Button saveData=button("💾 Simpan Data Denah");saveData.setOnClickListener(v->saveCad());content.addView(saveData);
        if(cadObjects.isEmpty())generateCad();
    }
    void generateCad(){cadObjects.clear();float W=Math.max(2000,num(cadWidth)),L=Math.max(2000,num(cadLength));cadObjects.add(new CadObj("ROOM",cadTitle==null||cadTitle.getText().length()==0?"RUANG":cadTitle.getText().toString(),0,0,W,L));cadObjects.add(new CadObj("DOOR","PINTU",W/2-450,-250,900,250));cadObjects.add(new CadObj("WINDOW","JENDELA",900,-250,1200,250));cadObjects.add(new CadObj("HEPA","HEPA",W/2-250,L/2-250,500,500));cadObjects.add(new CadObj("LIGHT","LAMP",W/2-150,1200,300,120));cadObjects.add(new CadObj("LIGHT","LAMP",W/2-150,3600,300,120));cadObjects.add(new CadObj("RETURN","RETURN",W-500,1600,300,300));cadObjects.add(new CadObj("AHU","AHU",250,300,700,500));cadObjects.add(new CadObj("TABLE","OPERATING TABLE",W/2-900,L/2-500,1800,1000));cadView.selected=-1;cadView.resetView();cadView.invalidate();Toast.makeText(this,"Denah otomatis berhasil dibuat",Toast.LENGTH_SHORT).show();}
    void cadObjectMenu(){String[] a={"Pintu","Jendela","HEPA Filter","Lampu","Return Air","AHU","Operating Table"};new AlertDialog.Builder(this).setTitle("Tambah objek CAD").setItems(a,(d,w)->{String[] t={"DOOR","WINDOW","HEPA","LIGHT","RETURN","AHU","TABLE"};cadObjects.add(new CadObj(t[w],a[w],500+cadObjects.size()*150,500+cadObjects.size()*100, w==0?900:400,w==0?250:400));cadView.selected=cadObjects.size()-1;cadView.invalidate();}).show();}
    void saveCad(){JSONArray a=new JSONArray();try{for(CadObj o:cadObjects){JSONObject j=new JSONObject();j.put("type",o.type);j.put("label",o.label);j.put("x",o.x);j.put("y",o.y);j.put("w",o.w);j.put("h",o.h);a.put(j);}prefs.edit().putString("cad",a.toString()).putString("cadTitle",cadTitle==null?"":cadTitle.getText().toString()).putString("cadW",cadWidth==null?"6000":cadWidth.getText().toString()).putString("cadL",cadLength==null?"8000":cadLength.getText().toString()).apply();Toast.makeText(this,"Denah tersimpan",Toast.LENGTH_SHORT).show();}catch(Exception e){Toast.makeText(this,"Gagal menyimpan denah",Toast.LENGTH_SHORT).show();}}
    void restoreCad(){if(cadView==null)return;String raw=prefs.getString("cad","");if(raw.isEmpty())return;try{cadObjects.clear();JSONArray a=new JSONArray(raw);for(int i=0;i<a.length();i++){JSONObject j=a.getJSONObject(i);cadObjects.add(new CadObj(j.optString("type","ROOM"),j.optString("label",""),(float)j.optDouble("x"),(float)j.optDouble("y"),(float)j.optDouble("w",400),(float)j.optDouble("h",400)));}cadView.invalidate();}catch(Exception ignored){}}
    void drawCadOnCanvas(Canvas c,Paint p,float ox,float oy,float sc){for(CadObj o:cadObjects){float x=ox+o.x*sc,y=oy+o.y*sc,w=o.w*sc,h=o.h*sc;p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(o.type.equals("ROOM")?2.5f:1.5f);p.setColor(o.type.equals("ROOM")?Color.rgb(20,63,91):Color.rgb(22,125,106));c.drawRect(x,y,x+w,y+h,p);p.setStyle(Paint.Style.FILL);p.setColor(Color.DKGRAY);p.setTextSize(Math.max(6,9*sc));c.drawText(o.label,x+3,y+Math.max(10,h/2),p);}p.setStyle(Paint.Style.STROKE);p.setColor(Color.GRAY);p.setStrokeWidth(1);c.drawRect(25,25,570,800,p);p.setStyle(Paint.Style.FILL);}
    File createCadPdfFile() throws Exception{PdfDocument pdf=new PdfDocument();PdfDocument.Page page=pdf.startPage(new PdfDocument.PageInfo.Builder(595,842,1).create());Canvas c=page.getCanvas();Paint p=new Paint(Paint.ANTI_ALIAS_FLAG);p.setColor(Color.rgb(20,63,91));p.setTypeface(Typeface.DEFAULT_BOLD);p.setTextSize(16);c.drawText("DENAH / CAD 2D",35,35,p);p.setTypeface(Typeface.DEFAULT);p.setTextSize(9);c.drawText(cadTitle==null?"":cadTitle.getText().toString(),35,52,p);c.drawText("Ukuran: "+fmt(num(cadWidth))+" × "+fmt(num(cadLength))+" mm",35,66,p);float W=Math.max(1,num(cadWidth)),L=Math.max(1,num(cadLength));float sc=Math.min(520/W,690/L);drawCadOnCanvas(c,p,35+(520-W*sc)/2,90+(690-L*sc)/2,sc);p.setTextSize(7);p.setColor(Color.DKGRAY);c.drawText("Skala otomatis agar seluruh denah masuk A4",35,815,p);pdf.finishPage(page);File dir=new File(getExternalFilesDir(Environment.DIRECTORY_DOCUMENTS),"RAB_RAP");if(!dir.exists())dir.mkdirs();File f=new File(dir,"DENAH_CAD_"+new SimpleDateFormat("yyyyMMdd_HHmmss",Locale.US)+".pdf");try(FileOutputStream os=new FileOutputStream(f)){pdf.writeTo(os);}pdf.close();lastPdf=f;return f;}
    void createCadPdf(){saveCad();try{File f=createCadPdfFile();openPdf(f);}catch(Exception e){Toast.makeText(this,"Gagal membuat PDF denah: "+e.getMessage(),Toast.LENGTH_LONG).show();}}
    void createCadPdfAndPrint(){try{File f=createCadPdfFile();PrintManager pm=(PrintManager)getSystemService(PRINT_SERVICE);pm.print("Denah CAD",new PdfPrintAdapter(this,f),new PrintAttributes.Builder().setMediaSize(PrintAttributes.MediaSize.ISO_A4).build());}catch(Exception e){Toast.makeText(this,"Gagal mencetak denah: "+e.getMessage(),Toast.LENGTH_LONG).show();}}

    void pageNotesOutput(){
        section("CATATAN & SYARAT"); notes=field("Syarat & ketentuan, termin pembayaran, garansi, catatan teknis..."); notes.setMinLines(7); addFieldTall("Catatan / Terms",notes,7);
        section("OUTPUT");
        Button save=button("💾 SIMPAN DATA"); save.setOnClickListener(v->saveAll()); content.addView(save);
        Button pdf=button("📄 BUAT & PREVIEW PDF"); pdf.setOnClickListener(v->createPdf(true)); content.addView(pdf);
        Button print=button("🖨 CETAK PDF TERAKHIR"); print.setOnClickListener(v->printLast()); content.addView(print);
        Button share=button("📤 BAGIKAN PDF TERAKHIR"); share.setOnClickListener(v->shareLast()); content.addView(share);
        Button savePdf=button("💾 SIMPAN PDF KE PERANGKAT"); savePdf.setOnClickListener(v->{try{File f=lastPdf!=null&&lastPdf.exists()?lastPdf:makePdfFile();saveToDevice(f);}catch(Exception e){Toast.makeText(this,"Gagal: "+e.getMessage(),Toast.LENGTH_LONG).show();}}); content.addView(savePdf);
        TextView info=text("File PDF dibuat melalui folder aplikasi yang aman dan dibagikan memakai FileProvider, sehingga tidak terkena error file:// pada Android 7+.",11,false); content.addView(info);
    }

    void loadProfile(){
        // Kept for compatibility; restoration is done once after all pages are created.
    }
    void restoreProfile(){
        restoreField(company,"company"); restoreField(address,"address"); restoreField(phone,"phone"); restoreField(email,"email"); restoreField(website,"website"); restoreField(npwp,"npwp"); restoreField(nib,"nib"); restoreField(bank,"bank"); restoreField(docNo,"docNo"); restoreField(project,"project"); restoreField(location,"location"); restoreField(customer,"customer"); restoreField(customerAddress,"customerAddress"); restoreField(pic,"pic"); restoreField(extra,"extra"); restoreField(discount,"discount"); restoreField(ppn,"ppn"); restoreField(pph,"pph"); restoreField(notes,"notes"); restoreCad();
        try{String raw=prefs.getString("items",""); if(!raw.isEmpty()){JSONArray a=new JSONArray(raw); if(a.length()>0){items.clear(); itemBox.removeAllViews(); itemCards.clear(); for(int k=0;k<a.length();k++){JSONObject o=a.getJSONObject(k);Item it=new Item();items.add(it);addItemView(it);it.name.setText(o.optString("name",""));it.desc.setText(o.optString("desc",""));it.brand.setText(o.optString("brand",""));it.model.setText(o.optString("model",""));it.unit.setText(o.optString("unit","unit"));it.qty.setText(o.optString("qty","1"));it.price.setText(o.optString("price","0"));it.itemDisc.setText(o.optString("disc","0"));it.internalCost.setText(o.optString("internal","0"));it.margin.setText(o.optString("margin","0"));}}}}catch(Exception ignored){}
        if(cadTitle!=null)cadTitle.setText(prefs.getString("cadTitle","")); if(cadWidth!=null)cadWidth.setText(prefs.getString("cadW","6000")); if(cadLength!=null)cadLength.setText(prefs.getString("cadL","8000"));
        String lu=prefs.getString("logoUri",""); String su=prefs.getString("signUri",""); String tu=prefs.getString("stampUri","");
        try{if(!lu.isEmpty()){logoUri=Uri.parse(lu);logoView.setImageURI(logoUri);}}catch(Exception ignored){}
        try{if(!su.isEmpty()){signUri=Uri.parse(su);signView.setImageURI(signUri);}}catch(Exception ignored){}
        try{if(!tu.isEmpty()){stampUri=Uri.parse(tu);stampView.setImageURI(stampUri);}}catch(Exception ignored){}
    }
    void saveAll(){
        if(company==null)return;
        SharedPreferences.Editor e=prefs.edit();
        e.putString("company",company.getText().toString()).putString("address",address.getText().toString()).putString("phone",phone.getText().toString()).putString("email",email.getText().toString()).putString("website",website.getText().toString()).putString("npwp",npwp.getText().toString()).putString("nib",nib.getText().toString()).putString("bank",bank.getText().toString()).putString("docNo",docNo==null?autoNo():docNo.getText().toString());
        if(project!=null)e.putString("project",project.getText().toString()).putString("location",location.getText().toString()).putString("customer",customer.getText().toString()).putString("customerAddress",customerAddress.getText().toString()).putString("pic",pic.getText().toString());
        if(extra!=null)e.putString("extra",extra.getText().toString()).putString("discount",discount.getText().toString()).putString("ppn",ppn.getText().toString()).putString("pph",pph.getText().toString());
        if(notes!=null)e.putString("notes",notes.getText().toString());
        JSONArray a=new JSONArray(); try{for(Item i:items){JSONObject o=new JSONObject();o.put("name",i.name.getText().toString());o.put("desc",i.desc.getText().toString());o.put("brand",i.brand.getText().toString());o.put("model",i.model.getText().toString());o.put("unit",i.unit.getText().toString());o.put("qty",i.qty.getText().toString());o.put("price",i.price.getText().toString());o.put("disc",i.itemDisc.getText().toString());o.put("internal",i.internalCost.getText().toString());o.put("margin",i.margin.getText().toString());a.put(o);}}catch(Exception ignored){} e.putString("items",a.toString()); e.apply();
        Toast.makeText(this,"Data tersimpan",Toast.LENGTH_SHORT).show();
    }
    void restoreField(EditText e,String key){ if(e!=null)e.setText(prefs.getString(key,"")); }

    void pick(int code){ Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT); i.setType("image/*"); i.addCategory(Intent.CATEGORY_OPENABLE); i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION|Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION); startActivityForResult(i,code); }
    @Override protected void onActivityResult(int request,int result,Intent data){
        super.onActivityResult(request,result,data); if(result!=RESULT_OK||data==null)return;
        if(request==SAVE_PDF){ if(pendingSave==null)return; try(InputStream in=new FileInputStream(pendingSave); OutputStream out=getContentResolver().openOutputStream(data.getData())){byte[]buf=new byte[8192];int n;while((n=in.read(buf))>0)out.write(buf,0,n);Toast.makeText(this,"PDF berhasil disimpan",Toast.LENGTH_LONG).show();}catch(Exception e){Toast.makeText(this,"Gagal menyimpan PDF: "+e.getMessage(),Toast.LENGTH_LONG).show();} return; }
        Uri u=data.getData(); try{getContentResolver().takePersistableUriPermission(u,Intent.FLAG_GRANT_READ_URI_PERMISSION);}catch(Exception ignored){}
        if(request==PICK_LOGO){logoUri=u;if(logoView!=null)logoView.setImageURI(u);prefs.edit().putString("logoUri",u.toString()).apply();} else if(request==PICK_SIGN){signUri=u;if(signView!=null)signView.setImageURI(u);prefs.edit().putString("signUri",u.toString()).apply();} else if(request==PICK_STAMP){stampUri=u;if(stampView!=null)stampView.setImageURI(u);prefs.edit().putString("stampUri",u.toString()).apply();}
    }

    double num(EditText e){ try{return Double.parseDouble(e.getText().toString().trim().replace(".","").replace(",","."));}catch(Exception x){return 0;} }
    double subtotal(){ double s=0; boolean rap=isRap(); for(Item i:items){ double q=num(i.qty), p=rap&&num(i.internalCost)>0?num(i.internalCost):num(i.price), d=num(i.itemDisc); s += q*p*(1-d/100); } return s; }
    boolean isRap(){return typeSpinner!=null && "RAP".equals(String.valueOf(typeSpinner.getSelectedItem()));}
    double extra(){return extra==null?0:num(extra);}
    String money(double n){return "Rp "+new DecimalFormat("#,##0",DecimalFormatSymbols.getInstance(new Locale("id","ID"))).format(Math.max(0,n));}
    void showTotals(){ double sub=subtotal()+extra(), dis=sub*num(discount)/100, dpp=Math.max(0,sub-dis), vat=dpp*num(ppn)/100, withholding=dpp*num(pph)/100, grand=dpp+vat; new AlertDialog.Builder(this).setTitle("Ringkasan").setMessage("Subtotal : "+money(sub)+"\nDiskon : "+money(dis)+"\nDPP : "+money(dpp)+"\nPPN : "+money(vat)+"\nPPh : "+money(withholding)+"\n\nGRAND TOTAL : "+money(grand)+"\nTerbilang : "+terbilang(Math.round(grand))+"\nNet setelah PPh : "+money(grand-withholding)).setPositiveButton("OK",null).show(); }

    File makePdfFile() throws Exception{
        double sub=subtotal()+extra(), dis=sub*num(discount)/100, dpp=Math.max(0,sub-dis), vat=dpp*num(ppn)/100, ph=dpp*num(pph)/100, grand=dpp+vat;
        PdfDocument pdf=new PdfDocument(); int pageNo=1; PdfDocument.Page page=pdf.startPage(new PdfDocument.PageInfo.Builder(595,842,pageNo).create()); Canvas c=page.getCanvas(); Paint p=new Paint(Paint.ANTI_ALIAS_FLAG); float y=42;
        drawHeader(c,p); y=195;
        // table header
        p.setColor(Color.rgb(20,63,91)); c.drawRect(35,y-14,560,y+12,p); p.setColor(Color.WHITE); p.setTypeface(Typeface.DEFAULT_BOLD); p.setTextSize(8); c.drawText("NO",40,y); c.drawText("URAIAN / SPESIFIKASI",68,y); c.drawText("UNIT",330,y); c.drawText("QTY",380,y); c.drawText("HARGA",420,y); c.drawText("TOTAL",505,y); y+=28; p.setTypeface(Typeface.DEFAULT); p.setColor(Color.DKGRAY);
        int no=1;
        for(Item it:items){
            String name=it.name.getText().toString().trim(); if(name.isEmpty())name="Item "+no; String desc=it.desc.getText().toString().replace("\n"," "); double q=num(it.qty), price=isRap()&&num(it.internalCost)>0?num(it.internalCost):num(it.price), id=num(it.itemDisc); double total=q*price*(1-id/100);
            if(y>735){ finishPage(pdf,page); pageNo++; page=pdf.startPage(new PdfDocument.PageInfo.Builder(595,842,pageNo).create()); c=page.getCanvas(); y=45; p.setColor(Color.DKGRAY); p.setTextSize(8); }
            c.drawText(""+no,40,y,p); c.drawText(shorten(name,42),68,y,p); c.drawText(shorten(it.unit.getText().toString(),8),330,y,p); c.drawText(fmt(q),380,y,p); c.drawText(fmt(price),420,y,p); c.drawText(fmt(total),505,y,p); y+=12;
            if(!desc.isEmpty()){c.drawText(shorten(desc,75),68,y,p);y+=12;} String spec=it.brand.getText().toString()+" "+it.model.getText().toString(); if(spec.trim().length()>0){c.drawText(shorten(spec,75),68,y,p);y+=12;} y+=8; no++;
        }
        if(y>690){finishPage(pdf,page);pageNo++;page=pdf.startPage(new PdfDocument.PageInfo.Builder(595,842,pageNo).create());c=page.getCanvas();y=60;}
        p.setTypeface(Typeface.DEFAULT_BOLD);p.setTextSize(9);p.setColor(Color.DKGRAY); c.drawText("Subtotal",380,y, p);c.drawText(money(sub),475,y,p);y+=17;c.drawText("Diskon",380,y,p);c.drawText(money(dis),475,y,p);y+=17;c.drawText("DPP",380,y,p);c.drawText(money(dpp),475,y,p);y+=17;c.drawText("PPN",380,y,p);c.drawText(money(vat),475,y,p);y+=17;c.drawText("PPh",380,y,p);c.drawText(money(ph),475,y,p);y+=23;p.setColor(Color.rgb(20,63,91));c.drawRect(365,y-14,560,y+13,p);p.setColor(Color.WHITE);p.setTextSize(10);c.drawText("GRAND TOTAL  "+money(grand),375,y+3,p);
        y+=45;p.setColor(Color.DKGRAY);p.setTextSize(8);p.setTypeface(Typeface.DEFAULT); c.drawText("Catatan / Syarat:",40,y,p);y+=13; String nt=notes==null?"":notes.getText().toString(); for(String line:wrap(nt,92)){if(y>805){break;}c.drawText(line,40,y,p);y+=11;}
        // signature images
        drawImage(c,p,signUri,420,730,70,50); drawImage(c,p,stampUri,480,710,60,60); finishPage(pdf,page);
        if(!cadObjects.isEmpty()){ pageNo++; page=pdf.startPage(new PdfDocument.PageInfo.Builder(595,842,pageNo).create()); c=page.getCanvas(); p.setColor(Color.rgb(20,63,91));p.setTypeface(Typeface.DEFAULT_BOLD);p.setTextSize(16);c.drawText("LAMPIRAN DENAH / CAD 2D",35,35,p);p.setTypeface(Typeface.DEFAULT);p.setTextSize(9);c.drawText(cadTitle==null?"":cadTitle.getText().toString(),35,52,p);float W=Math.max(1,num(cadWidth)),L=Math.max(1,num(cadLength));float sc=Math.min(520/W,690/L);drawCadOnCanvas(c,p,35+(520-W*sc)/2,90+(690-L*sc)/2,sc);finishPage(pdf,page);}
        File dir=new File(getExternalFilesDir(Environment.DIRECTORY_DOCUMENTS),"RAB_RAP"); if(!dir.exists()&&!dir.mkdirs())throw new IOException("Tidak dapat membuat folder PDF"); File f=new File(dir,"RAB_RAP_"+new SimpleDateFormat("yyyyMMdd_HHmmss",Locale.US).format(new Date())+".pdf"); FileOutputStream os=new FileOutputStream(f);pdf.writeTo(os);os.close();pdf.close();lastPdf=f;return f;
    }
    void finishPage(PdfDocument pdf,PdfDocument.Page page){pdf.finishPage(page);}
    void drawHeader(Canvas c,Paint p){
        p.setColor(Color.rgb(20,63,91));p.setTypeface(Typeface.DEFAULT_BOLD);p.setTextSize(22);c.drawText(company==null||company.getText().length()==0?"NAMA PERUSAHAAN":company.getText().toString(),40,40,p);p.setTypeface(Typeface.DEFAULT);p.setTextSize(8);p.setColor(Color.DKGRAY);c.drawText(address==null?"":address.getText().toString(),40,58,p);c.drawText((phone==null?"":phone.getText().toString())+"  "+(email==null?"":email.getText().toString()),40,71,p);c.drawText((website==null?"":website.getText().toString())+"  NPWP: "+(npwp==null?"":npwp.getText().toString()),40,84,p);drawImage(c,p,logoUri,485,24,65,55);p.setColor(Color.rgb(22,125,106));c.drawRect(40,95,555,99,p);p.setColor(Color.rgb(20,63,91));p.setTypeface(Typeface.DEFAULT_BOLD);p.setTextSize(16);c.drawText(typeSpinner==null?"QUOTATION":typeSpinner.getSelectedItem().toString(),40,125,p);p.setTypeface(Typeface.DEFAULT);p.setTextSize(8);c.drawText("No: "+(docNo==null?"":docNo.getText().toString()),390,122,p);c.drawText("Project: "+(project==null?"":project.getText().toString()),40,145,p);c.drawText("Kepada: "+(customer==null?"":customer.getText().toString()),40,160,p);c.drawText("PIC: "+(pic==null?"":pic.getText().toString())+"  |  Lokasi: "+(location==null?"":location.getText().toString()),40,175,p); if(isRap()){p.setTypeface(Typeface.DEFAULT_BOLD);c.drawText("DOKUMEN INTERNAL RAP",450,175,p);p.setTypeface(Typeface.DEFAULT);}
    }
    void drawImage(Canvas c,Paint p,Uri u,float x,float y,float w,float h){if(u==null)return;try{Bitmap b=BitmapFactory.decodeStream(getContentResolver().openInputStream(u));if(b!=null)c.drawBitmap(b,null,new RectF(x,y,x+w,y+h),p);}catch(Exception ignored){}}
    String shorten(String s,int max){s=s==null?"":s.trim();return s.length()>max?s.substring(0,max-1)+"…":s;}
    ArrayList<String> wrap(String s,int max){ArrayList<String>a=new ArrayList<>();if(s==null||s.isEmpty())return a;for(String part:s.split("\\n")){while(part.length()>max){a.add(part.substring(0,max));part=part.substring(max);}if(!part.isEmpty())a.add(part);}return a;}
    String fmt(double n){return new DecimalFormat("#,##0",DecimalFormatSymbols.getInstance(new Locale("id","ID"))).format(n);}

    String terbilang(long n){String[] w={"nol","satu","dua","tiga","empat","lima","enam","tujuh","delapan","sembilan","sepuluh","sebelas"}; if(n<12)return w[(int)n]; if(n<20)return w[(int)(n-10)]+" belas"; if(n<100)return w[(int)(n/10)]+" puluh"+(n%10>0?" "+terbilang(n%10):""); if(n<200)return "seratus"+(n%100>0?" "+terbilang(n%100):""); if(n<1000)return terbilang(n/100)+" ratus"+(n%100>0?" "+terbilang(n%100):""); if(n<2000)return "seribu"+(n%1000>0?" "+terbilang(n%1000):""); if(n<1000000)return terbilang(n/1000)+" ribu"+(n%1000>0?" "+terbilang(n%1000):""); if(n<1000000000)return terbilang(n/1000000)+" juta"+(n%1000000>0?" "+terbilang(n%1000000):""); if(n<1000000000000L)return terbilang(n/1000000000)+" miliar"+(n%1000000000>0?" "+terbilang(n%1000000000):""); return terbilang(n/1000000000000L)+" triliun"+(n%1000000000000L>0?" "+terbilang(n%1000000000000L):"");}
    void createPdf(boolean preview){ saveAll(); try{File f=makePdfFile(); if(preview)openPdf(f); else Toast.makeText(this,"PDF tersimpan",Toast.LENGTH_LONG).show();}catch(Exception e){Toast.makeText(this,"Gagal membuat PDF: "+e.getMessage(),Toast.LENGTH_LONG).show();}}
    Uri uriFor(File f){return FileProvider.getUriForFile(this,getPackageName()+".fileprovider",f);}
    void openPdf(File f){try{Intent i=new Intent(Intent.ACTION_VIEW);i.setDataAndType(uriFor(f),"application/pdf");i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);startActivity(i);}catch(Exception e){shareFile(f);}}
    void shareFile(File f){Intent i=new Intent(Intent.ACTION_SEND);i.setType("application/pdf");i.putExtra(Intent.EXTRA_STREAM,uriFor(f));i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);startActivity(Intent.createChooser(i,"Bagikan PDF"));}
    void saveToDevice(File f){Intent i=new Intent(Intent.ACTION_CREATE_DOCUMENT);i.setType("application/pdf");i.putExtra(Intent.EXTRA_TITLE,f.getName());startActivityForResult(i,SAVE_PDF);pendingSave=f;}
    File pendingSave;
    void shareLast(){if(lastPdf!=null&&lastPdf.exists())shareFile(lastPdf);else Toast.makeText(this,"Buat PDF terlebih dahulu",Toast.LENGTH_SHORT).show();}
    void printLast(){if(lastPdf==null||!lastPdf.exists()){Toast.makeText(this,"Buat PDF terlebih dahulu",Toast.LENGTH_SHORT).show();return;}try{PrintManager pm=(PrintManager)getSystemService(PRINT_SERVICE);pm.print("RAB_RAP_PRO",new PdfPrintAdapter(this,lastPdf),new PrintAttributes.Builder().setMediaSize(PrintAttributes.MediaSize.ISO_A4).build());}catch(Exception e){Toast.makeText(this,"Fitur cetak tidak tersedia: "+e.getMessage(),Toast.LENGTH_LONG).show();}}

    static class PdfPrintAdapter extends android.print.PrintDocumentAdapter{
        final Context c; final File f; PdfPrintAdapter(Context c,File f){this.c=c;this.f=f;}
        @Override public void onLayout(PrintAttributes oldA,PrintAttributes newA,android.print.PageRange[] pages,android.os.CancellationSignal cs,LayoutResultCallback cb,Bundle extras){if(cs.isCanceled()){cb.onLayoutCancelled();return;}cb.onLayoutFinished(new PrintDocumentInfo.Builder(f.getName()).setContentType(PrintDocumentInfo.CONTENT_TYPE_DOCUMENT).setPageCount(PrintDocumentInfo.PAGE_COUNT_UNKNOWN).build(),true);}
        @Override public void onWrite(android.print.PageRange[] pages,android.os.ParcelFileDescriptor dest,android.os.CancellationSignal cs,WriteResultCallback cb){try(FileInputStream in=new FileInputStream(f);FileOutputStream out=new FileOutputStream(dest.getFileDescriptor())){byte[]buf=new byte[8192];int n;while((n=in.read(buf))>0)out.write(buf,0,n);cb.onWriteFinished(new android.print.PageRange[]{android.print.PageRange.ALL_PAGES});}catch(Exception e){cb.onWriteFailed(e.getMessage());}}
    }

    void outputMenu(){new AlertDialog.Builder(this).setTitle("Output dokumen").setItems(new String[]{"📄 Buat & Preview PDF","💾 Simpan PDF ke perangkat","📤 Bagikan PDF","🖨 Cetak PDF","💾 Simpan data"},(d,w)->{if(w==0)createPdf(true);else if(w==1){try{File f=lastPdf!=null&&lastPdf.exists()?lastPdf:makePdfFile();saveToDevice(f);}catch(Exception e){Toast.makeText(this,"Gagal: "+e.getMessage(),Toast.LENGTH_LONG).show();}}else if(w==2)shareLast();else if(w==3)printLast();else saveAll();}).show();}
    @Override protected void onPause(){ super.onPause(); try{saveAllSilent();}catch(Exception ignored){} }
    void saveAllSilent(){ if(company==null)return; SharedPreferences.Editor e=prefs.edit(); e.putString("company",company.getText().toString()).putString("address",address.getText().toString()).putString("phone",phone.getText().toString()).putString("email",email.getText().toString()).putString("website",website.getText().toString()).putString("npwp",npwp.getText().toString()).putString("nib",nib.getText().toString()).putString("bank",bank.getText().toString()).putString("docNo",docNo.getText().toString()).putString("project",project.getText().toString()).putString("location",location.getText().toString()).putString("customer",customer.getText().toString()).putString("customerAddress",customerAddress.getText().toString()).putString("pic",pic.getText().toString()).putString("extra",extra.getText().toString()).putString("discount",discount.getText().toString()).putString("ppn",ppn.getText().toString()).putString("pph",pph.getText().toString()).putString("notes",notes.getText().toString()); e.apply(); saveCadSilent(); }
    void saveCadSilent(){ if(cadView==null)return; try{JSONArray a=new JSONArray();for(CadObj o:cadObjects){JSONObject j=new JSONObject();j.put("type",o.type);j.put("label",o.label);j.put("x",o.x);j.put("y",o.y);j.put("w",o.w);j.put("h",o.h);a.put(j);}prefs.edit().putString("cad",a.toString()).putString("cadTitle",cadTitle==null?"":cadTitle.getText().toString()).putString("cadW",cadWidth==null?"6000":cadWidth.getText().toString()).putString("cadL",cadLength==null?"8000":cadLength.getText().toString()).apply();}catch(Exception ignored){} }
    @Override public void onBackPressed(){if(page>0)showPage(page-1);else super.onBackPressed();}
}
