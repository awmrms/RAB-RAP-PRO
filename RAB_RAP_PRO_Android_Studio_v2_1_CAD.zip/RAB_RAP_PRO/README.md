# RAB RAP PRO 2.0

Android Studio project untuk RAB, RAP dan QUOTATION.

## Pembaruan utama
- UI responsif tanpa ukuran layar tetap; mendukung HP kecil, tablet dan landscape.
- Wizard 5 langkah dengan tombol **Kembali** dan **Lanjut** serta Android Back.
- Profil perusahaan lengkap: logo, tanda tangan, stempel, kontak, NPWP, NIB, website, rekening.
- Data dokumen: RAB/RAP/Quotation, nomor, proyek, lokasi, customer, PIC, template.
- Item: deskripsi, brand, model, unit, qty, harga, diskon item.
- Pajak: diskon, PPN, PPh dan jenis PPh.
- PDF A4 multi-page dengan logo/tanda tangan/stempel jika tersedia.
- Share PDF menggunakan FileProvider (menghindari FileUriExposedException).
- Preview PDF menggunakan aplikasi pembaca PDF yang terpasang.
- Cetak melalui Android Print Framework.
- File PDF disimpan di folder aplikasi Documents/RAB_RAP.

## Catatan build
Buka folder ini di Android Studio, lakukan Gradle Sync, lalu Build > Build APK(s).
Versi aplikasi 2.0, minSdk 24, target/compile SDK 35.

## Versi 2.1 - Denah / CAD 2D
- Modul Denah/CAD 2D responsif.
- Generate denah otomatis berdasarkan lebar dan panjang ruangan dalam mm.
- Objek: dinding/ruang, pintu, jendela, HEPA filter, lampu, return air, AHU, operating table.
- Objek dapat dipilih dan digeser dengan sentuhan.
- Tambah/hapus objek, reset, Zoom +, Zoom -, Fit.
- Simpan data denah ke SharedPreferences.
- Export denah ke PDF A4 dengan skala otomatis.
- Simpan PDF melalui Android Storage Access Framework.
- Cetak denah menggunakan Android Print Framework.
- Saat membuat PDF RAB/RAP/Quotation, denah otomatis ditambahkan sebagai lampiran halaman CAD jika tersedia.
